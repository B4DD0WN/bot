exports.nzul = (id, B4DD0WN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) => {
	return `
  
❉──────────❉
*MENU4 ${B4DD0WN}*
❉──────────❉
╔════════════════════
║ *MENU ALL BOT ${B4DD0WN}*
╠════════════════════
║║═════❉ *OTHERS* ❉═══════║
║➢ 1. _*!sticker*_ 
║➢ 2. _*!tts*_ <teks>
║➢ 3. _*!quotes*_
║➢ 4. _*!tinyurl*_ <link>
║➢ 5. _*!foto cewek*_
║➢ 6. _*!foto cowok*_
║➢ 7. _*!pokemon*_
║➢ 8. _*!loli*_
║➢ 9. _*!fotoanime*_
║➢ 10. _*!namaninja*_ <nama lu>
║➢ 11. _*!alay*_ <teks>
║➢ 12. _*!infoig*_ <@username>
║➢ 13. _*!ocr*_
║➢ 14. _*!puisi1*_
║➢ 15. _*!puisi2*_
║➢ 16. _*!cerpen*_
║➢ 17. _*!quotes1*_
║➢ 18. _*!spamcall*_ <85722553839>
║➢ 19. _*!spamsms*_ <85722553839>
║➢ 20. _*!bucin*_
║➢ 21. _*!gay*_
║➢ 22. _*!indohot*_
║➢ 23. _*!cersex1*_
║➢ 24. _*!cersex2*_
║➢ 25. _*!cekumur <nzul & 14-12-2003> (New)*_
║➢ 26. _*!cekresi <resi & kurir> (New)*_
║➢ 27. _*!selamat <...> ganti dengan kata kata*_
║➢ 28. _*!sfrom <link>*_.
║➢ 29. _*!meme1*_
║➢ 30. _*!zodiak <& 14-12-2003>*_
║➢ 31. _*!jadwaltv <sctv>*_
║➢ 32. _*!cinta <nzul>*_
║═══════════════════
╔════════════════════
║ *MENU BOT ${B4DD0WN}*
╠════════════════════
║║════❉ *EDUCATION* ❉═════│
║➢ 1. _*!wiki*_ <query>Wikipedia.
║➢ 2. _*!nulis*_ <teks>
║➢ 3. *!quran*
║➢ 4. _*!pantun*_
║➢ 5. _*!nama*_ <nama anda>
║➢ 6. _*!pasangan*_ <Gw & Lo>
║➢ 7. _*!lirik*_ <nama lagu>
║➢ 8. _*!chord*_ <nama lagu>
║➢ 9. _*!resep*_ <nasi goreng>
║➢ 10. _*!wikien*_ <query>Versi English
║═══════════════════
╠═══════════════════
╔════════════════════
║ *MENU BOT ${B4DD0WN}*
╠════════════════════
║║════❉ *INFORMATION* ❉════│
║➢ 1. _*!sholat*_ <daerah>
║➢ 2. _*!covid*_
║➢ 3. _*!infogempa*_ 
║➢ 4. _*!harinasional*_ <tanggal>
║➢ 5. _*!infoanime*_ <Naruto>
║➢ 6. _*!filmanime*_ <Naruto>
║➢ 7. _*!ytmp3*_ <linkyt>
║➢ 8. _*!ytmp4*_ <linkyt>
║➢ 9. _*!fb*_ <linkvideofb>
║➢ 10. _*!say*_ <!say ajg>
║═════════════════
╠════════════════════
╠════════════════════
║ INFO *${B4DD0WN}*
╠════════════════════
║║═════❉ * INFO BOT * ❉═════│
║➢ 1. *#info*
║➢ 2. *#owner*
║➢ 3. *#donasi*
║➢ 4. *#S&K*
║══════════════════
╠════════════════════
╠════════════════════
║  *${XNZUL}*
╠════════════════════
║║═══❉ *SOSMED ADMIN* ❉═══│
║➢ 1. *Group WhatsApp*
║➢  _${groupwhatsapp}_
║➢ 2. *YouTube <subscribe>*
║➢  _${youtube}_
║➢ 3. *Instagram <Follow>*
║➢  _${instagram}_
║➢ 4. *Creator ${B4DD0WN}*
║➢  _${nomer}_
║═════════════════
╠════════════════════
║ _*MADE BY B4DD0WN*_
╚════════════════════`
}
