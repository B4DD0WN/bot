exports.menuall = (id, B4DD0WN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) => {
	return `
  
❉──────────❉

*MENU BOT ${B4DD0WN}*

❉──────────❉

📆 *${tampilTanggal}*

╔════════════════════
║ *MENU BOT ${B4DD0WN}*
╠════════════════════
║➢ 1. _*#menu1*_
║➢ 2. _*#menu2*_
║➢ 3. _*#menu3*_
║➢ 4. _*#menu4*_
║➢ 5. _*#menuall*_
║➢ 6. _*#simi (New)*_
║➢ 7. _*#info*_
║➢ 8. _*#S&K*_
║➢ 9. _*#donasi*_
║➢ 10. _*#creator*_
║➢ 11. _*#owner*_
╠════════════════════
║ _*Sunda XPloit Indonesia*_
║ _*Untuk Mengundang BOT Ini Kedalam*_
║ _*Group Silahkan Donasi Dulu Ya Kak*_
╠════════════════════
║ _*Copyright By B4DD0WN(*_
╚════════════════════`
}
